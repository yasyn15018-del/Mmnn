
import '../models/unit.dart';

class DataService {
  static List<Unit> units = [];
}
