
class Unit {
  String number;
  String owner;
  Unit({required this.number, required this.owner});
}
