
import 'package:flutter/material.dart';
import '../models/unit.dart';
import '../services/data_service.dart';
import 'add_unit_screen.dart';

class UnitsScreen extends StatefulWidget {
  @override
  State<UnitsScreen> createState() => _UnitsScreenState();
}

class _UnitsScreenState extends State<UnitsScreen> {
  @override
  Widget build(BuildContext context) {
    List<Unit> units = DataService.units;
    return Scaffold(
      appBar: AppBar(title: Text("واحدها")),
      floatingActionButton: FloatingActionButton(
        child: Icon(Icons.add),
        onPressed: () async {
          await Navigator.push(context, MaterialPageRoute(builder: (_) => AddUnitScreen()));
          setState(() {});
        },
      ),
      body: ListView.builder(
        itemCount: units.length,
        itemBuilder: (context, index) {
          var u = units[index];
          return ListTile(
            leading: Icon(Icons.door_front_door),
            title: Text("واحد ${u.number}"),
            subtitle: Text("مالک: ${u.owner}"),
          );
        },
      ),
    );
  }
}
