
import 'package:flutter/material.dart';
import 'units_screen.dart';
import 'payments_screen.dart';
import 'notices_screen.dart';

class HomeScreen extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: Text("مدیریت ساختمان"), centerTitle: true),
      body: GridView.count(
        padding: EdgeInsets.all(20),
        crossAxisCount: 2,
        children: [
          _buildItem(context, "واحدها", Icons.apartment, UnitsScreen()),
          _buildItem(context, "پرداخت‌ها", Icons.payments, PaymentsScreen()),
          _buildItem(context, "اعلان‌ها", Icons.notifications, NoticesScreen()),
        ],
      ),
    );
  }

  Widget _buildItem(BuildContext context, String title, IconData icon, Widget screen) {
    return InkWell(
      onTap: () => Navigator.push(context, MaterialPageRoute(builder: (_) => screen)),
      child: Card(
        elevation: 3,
        child: Column(mainAxisAlignment: MainAxisAlignment.center, children: [
          Icon(icon, size: 45),
          SizedBox(height: 10),
          Text(title, style: TextStyle(fontSize: 18))
        ]),
      ),
    );
  }
}
