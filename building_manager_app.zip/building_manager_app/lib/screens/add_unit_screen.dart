
import 'package:flutter/material.dart';
import '../models/unit.dart';
import '../services/data_service.dart';

class AddUnitScreen extends StatefulWidget {
  @override
  State<AddUnitScreen> createState() => _AddUnitScreenState();
}

class _AddUnitScreenState extends State<AddUnitScreen> {
  final _numController = TextEditingController();
  final _ownerController = TextEditingController();

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: Text("افزودن واحد")),
      body: Padding(
        padding: EdgeInsets.all(20),
        child: Column(
          children: [
            TextField(controller: _numController, decoration: InputDecoration(labelText: "شماره واحد")),
            TextField(controller: _ownerController, decoration: InputDecoration(labelText: "نام مالک")),
            SizedBox(height: 20),
            ElevatedButton(
              onPressed: () {
                DataService.units.add(Unit(number: _numController.text, owner: _ownerController.text));
                Navigator.pop(context);
              },
              child: Text("ذخیره"),
            )
          ],
        ),
      ),
    );
  }
}
