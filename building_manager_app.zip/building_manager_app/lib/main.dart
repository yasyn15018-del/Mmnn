
import 'package:flutter/material.dart';
import 'screens/home_screen.dart';

void main() {
  runApp(BuildingManagerApp());
}

class BuildingManagerApp extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      debugShowCheckedModeBanner: false,
      title: 'مدیریت ساختمان',
      theme: ThemeData(
        primarySwatch: Colors.blue,
        fontFamily: 'Vazirmatn',
      ),
      home: HomeScreen(),
    );
  }
}
